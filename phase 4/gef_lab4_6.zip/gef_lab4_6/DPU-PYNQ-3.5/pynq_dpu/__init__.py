# Copyright (C) 2021 Xilinx, Inc
#
# SPDX-License-Identifier: Apache-2.0

from .dpu import DpuOverlay

__version__ = '3.5.0'
